# Online Retail
Features :

InvoiceNo
StockCode
Description
Quantity
Invoice Date
UnitPrice
CustomerID
Country

```python
# Library
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os

%matplotlib inline
```


```python
df = pd.read_excel("Online_Retail.xlsx")
```


```python
df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Description</th>
      <th>Quantity</th>
      <th>InvoiceDate</th>
      <th>UnitPrice</th>
      <th>CustomerID</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>536365</td>
      <td>85123A</td>
      <td>WHITE HANGING HEART T-LIGHT HOLDER</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>2.55</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>1</th>
      <td>536365</td>
      <td>71053</td>
      <td>WHITE METAL LANTERN</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>2</th>
      <td>536365</td>
      <td>84406B</td>
      <td>CREAM CUPID HEARTS COAT HANGER</td>
      <td>8</td>
      <td>2010-12-01 08:26:00</td>
      <td>2.75</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>3</th>
      <td>536365</td>
      <td>84029G</td>
      <td>KNITTED UNION FLAG HOT WATER BOTTLE</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>4</th>
      <td>536365</td>
      <td>84029E</td>
      <td>RED WOOLLY HOTTIE WHITE HEART.</td>
      <td>6</td>
      <td>2010-12-01 08:26:00</td>
      <td>3.39</td>
      <td>17850.0</td>
      <td>United Kingdom</td>
    </tr>
  </tbody>
</table>
</div>




```python
df=df[['CustomerID','InvoiceNo','StockCode','Quantity','UnitPrice','Description','InvoiceDate','Country']]
```


```python
df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Quantity</th>
      <th>UnitPrice</th>
      <th>Description</th>
      <th>InvoiceDate</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>85123A</td>
      <td>6</td>
      <td>2.55</td>
      <td>WHITE HANGING HEART T-LIGHT HOLDER</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>1</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>71053</td>
      <td>6</td>
      <td>3.39</td>
      <td>WHITE METAL LANTERN</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>2</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84406B</td>
      <td>8</td>
      <td>2.75</td>
      <td>CREAM CUPID HEARTS COAT HANGER</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>3</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84029G</td>
      <td>6</td>
      <td>3.39</td>
      <td>KNITTED UNION FLAG HOT WATER BOTTLE</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>4</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84029E</td>
      <td>6</td>
      <td>3.39</td>
      <td>RED WOOLLY HOTTIE WHITE HEART.</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Data Preprocessing
df.isnull().sum()
```




    CustomerID     135080
    InvoiceNo           0
    StockCode           0
    Quantity            0
    UnitPrice           0
    Description      1454
    InvoiceDate         0
    Country             0
    dtype: int64




```python
TotalAmount = df['Quantity'] * df['UnitPrice']
df.insert(loc=5,column='TotalAmount',value=TotalAmount)
```


```python
TotalAmount.head(10)
```




    0    15.30
    1    20.34
    2    22.00
    3    20.34
    4    20.34
    5    15.30
    6    25.50
    7    11.10
    8    11.10
    9    54.08
    dtype: float64




```python
new_df = df[['CustomerID','InvoiceNo','StockCode','Quantity','TotalAmount','InvoiceDate','Country']]

new_df2 = df.copy()
```


```python
new_df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Quantity</th>
      <th>TotalAmount</th>
      <th>InvoiceDate</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>85123A</td>
      <td>6</td>
      <td>15.30</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>1</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>71053</td>
      <td>6</td>
      <td>20.34</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>2</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84406B</td>
      <td>8</td>
      <td>22.00</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>3</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84029G</td>
      <td>6</td>
      <td>20.34</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>4</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84029E</td>
      <td>6</td>
      <td>20.34</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
  </tbody>
</table>
</div>




```python
country_price = new_df.groupby('Country')['Quantity'].sum().sort_values(ascending = False)
country_price
```




    Country
    United Kingdom          4263829
    Netherlands              200128
    EIRE                     142637
    Germany                  117448
    France                   110480
    Australia                 83653
    Sweden                    35637
    Switzerland               30325
    Spain                     26824
    Japan                     25218
    Belgium                   23152
    Norway                    19247
    Portugal                  16180
    Finland                   10666
    Channel Islands            9479
    Denmark                    8188
    Italy                      7999
    Cyprus                     6317
    Singapore                  5234
    Austria                    4827
    Hong Kong                  4769
    Israel                     4353
    Poland                     3653
    Unspecified                3300
    Canada                     2763
    Iceland                    2458
    Greece                     1556
    USA                        1034
    United Arab Emirates        982
    Malta                       944
    Lithuania                   652
    Czech Republic              592
    European Community          497
    Lebanon                     386
    Brazil                      356
    RSA                         352
    Bahrain                     260
    Saudi Arabia                 75
    Name: Quantity, dtype: int64




```python
# Top 5 Companies 
country_price[:5].plot(kind = 'bar')
```




    <Axes: xlabel='Country'>




    
![png](output_13_1.png)
    



```python
# 5 Compaies with least number of purchase
country_price[33:].plot(kind = 'bar')

```




    <Axes: xlabel='Country'>




    
![png](output_14_1.png)
    



```python
timest = new_df['InvoiceDate'].dt.year

new_df['Year'] = timest

new_df.head()
```

    C:\Users\Admin\AppData\Local\Temp\ipykernel_7368\3162078452.py:3: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      new_df['Year'] = timest
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Quantity</th>
      <th>TotalAmount</th>
      <th>InvoiceDate</th>
      <th>Country</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>85123A</td>
      <td>6</td>
      <td>15.30</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>1</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>71053</td>
      <td>6</td>
      <td>20.34</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>2</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84406B</td>
      <td>8</td>
      <td>22.00</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>3</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84029G</td>
      <td>6</td>
      <td>20.34</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>4</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84029E</td>
      <td>6</td>
      <td>20.34</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
      <td>2010</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Total sales for different years

new_df.groupby('Year')['TotalAmount'].sum().plot(kind = 'bar')
```




    <Axes: xlabel='Year'>




    
![png](output_16_1.png)
    



```python
# Sales for different months

new_df['Mon'] = new_df['InvoiceDate'].dt.month
new_df['month'] = new_df['InvoiceDate'].dt.month_name() 
new_df.groupby(['Mon','Year'])['TotalAmount'].sum().plot(kind = 'bar', title = 'Sales month wise')
```




    <Axes: title={'center': 'Sales month wise'}, xlabel='Mon,Year'>




    
![png](output_17_1.png)
    



```python
# Checking why dec 2011 has a drop comparing to nov 2011
get_2011 = new_df[(new_df['Year'] == 2011)]
get_dec2011 = get_2011[(new_df['month'] == 'December')]
get_dec2011 = get_dec2011['InvoiceDate'].dt.date.unique()
get_dec2011
```

    C:\Users\Admin\AppData\Local\Temp\ipykernel_7368\2588636060.py:3: UserWarning: Boolean Series key will be reindexed to match DataFrame index.
      get_dec2011 = get_2011[(new_df['month'] == 'December')]
    




    array([datetime.date(2011, 12, 1), datetime.date(2011, 12, 2),
           datetime.date(2011, 12, 4), datetime.date(2011, 12, 5),
           datetime.date(2011, 12, 6), datetime.date(2011, 12, 7),
           datetime.date(2011, 12, 8), datetime.date(2011, 12, 9)],
          dtype=object)




```python
new_df.head(6)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Quantity</th>
      <th>TotalAmount</th>
      <th>InvoiceDate</th>
      <th>Country</th>
      <th>Year</th>
      <th>Mon</th>
      <th>month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>85123A</td>
      <td>6</td>
      <td>15.30</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
      <td>2010</td>
      <td>12</td>
      <td>December</td>
    </tr>
    <tr>
      <th>1</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>71053</td>
      <td>6</td>
      <td>20.34</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
      <td>2010</td>
      <td>12</td>
      <td>December</td>
    </tr>
    <tr>
      <th>2</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84406B</td>
      <td>8</td>
      <td>22.00</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
      <td>2010</td>
      <td>12</td>
      <td>December</td>
    </tr>
    <tr>
      <th>3</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84029G</td>
      <td>6</td>
      <td>20.34</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
      <td>2010</td>
      <td>12</td>
      <td>December</td>
    </tr>
    <tr>
      <th>4</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84029E</td>
      <td>6</td>
      <td>20.34</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
      <td>2010</td>
      <td>12</td>
      <td>December</td>
    </tr>
    <tr>
      <th>5</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>22752</td>
      <td>2</td>
      <td>15.30</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
      <td>2010</td>
      <td>12</td>
      <td>December</td>
    </tr>
  </tbody>
</table>
</div>




```python
# removes all rows that contain null values in the specified column
new_df = new_df.dropna()

```


```python
new_df.isnull().sum()
```




    CustomerID     0
    InvoiceNo      0
    StockCode      0
    Quantity       0
    TotalAmount    0
    InvoiceDate    0
    Country        0
    Year           0
    Mon            0
    month          0
    dtype: int64




```python
#Countries with more number of customers
cus_id = pd.DataFrame(new_df.groupby('Country')['CustomerID'].count().sort_values(ascending = False))
cus_id[:5].plot(kind = 'bar', title = 'Most Customers for country')
```




    <Axes: title={'center': 'Most Customers for country'}, xlabel='Country'>




    
![png](output_22_1.png)
    



```python
# Countries with less number of customers
cus_id[-5:].plot(kind = 'bar', title = 'Least customers for country')
```




    <Axes: title={'center': 'Least customers for country'}, xlabel='Country'>




    
![png](output_23_1.png)
    



```python
# Removing the null values since we are checking the data based on customer and description
new_df2 = new_df2.dropna()
new_df2.isnull().sum()
new_df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>InvoiceNo</th>
      <th>StockCode</th>
      <th>Quantity</th>
      <th>UnitPrice</th>
      <th>TotalAmount</th>
      <th>Description</th>
      <th>InvoiceDate</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>85123A</td>
      <td>6</td>
      <td>2.55</td>
      <td>15.30</td>
      <td>WHITE HANGING HEART T-LIGHT HOLDER</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>1</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>71053</td>
      <td>6</td>
      <td>3.39</td>
      <td>20.34</td>
      <td>WHITE METAL LANTERN</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>2</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84406B</td>
      <td>8</td>
      <td>2.75</td>
      <td>22.00</td>
      <td>CREAM CUPID HEARTS COAT HANGER</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>3</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84029G</td>
      <td>6</td>
      <td>3.39</td>
      <td>20.34</td>
      <td>KNITTED UNION FLAG HOT WATER BOTTLE</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
    <tr>
      <th>4</th>
      <td>17850.0</td>
      <td>536365</td>
      <td>84029E</td>
      <td>6</td>
      <td>3.39</td>
      <td>20.34</td>
      <td>RED WOOLLY HOTTIE WHITE HEART.</td>
      <td>2010-12-01 08:26:00</td>
      <td>United Kingdom</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Sales Average of each product

avg_sales = new_df2.groupby(['StockCode','Description'])['Quantity','TotalAmount'].mean().sort_values(by = 'Quantity',ascending = False)
avg_sales
```

    C:\Users\Admin\AppData\Local\Temp\ipykernel_7368\682797469.py:3: FutureWarning: Indexing with multiple keys (implicitly converted to a tuple of keys) will be deprecated, use a list instead.
      avg_sales = new_df2.groupby(['StockCode','Description'])['Quantity','TotalAmount'].mean().sort_values(by = 'Quantity',ascending = False)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Quantity</th>
      <th>TotalAmount</th>
    </tr>
    <tr>
      <th>StockCode</th>
      <th>Description</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>47556B</th>
      <th>TEA TIME TEA TOWELS</th>
      <td>1300.000000</td>
      <td>3022.500000</td>
    </tr>
    <tr>
      <th>84568</th>
      <th>GIRLS ALPHABET IRON ON PATCHES</th>
      <td>520.000000</td>
      <td>97.200000</td>
    </tr>
    <tr>
      <th>84826</th>
      <th>ASSTD DESIGN 3D PAPER STICKERS</th>
      <td>368.702703</td>
      <td>9.145405</td>
    </tr>
    <tr>
      <th>18007</th>
      <th>ESSENTIAL BALM 3.5g TIN IN ENVELOPE</th>
      <td>325.333333</td>
      <td>21.320000</td>
    </tr>
    <tr>
      <th>20914</th>
      <th>SET/5 RED SPOTTY LID GLASS BOWLS</th>
      <td>288.000000</td>
      <td>734.400000</td>
    </tr>
    <tr>
      <th>...</th>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>21412</th>
      <th>VINTAGE GOLD TINSEL REEL</th>
      <td>-6.000000</td>
      <td>-2.520000</td>
    </tr>
    <tr>
      <th>79323W</th>
      <th>WHITE CHERRY LIGHTS</th>
      <td>-8.000000</td>
      <td>-54.000000</td>
    </tr>
    <tr>
      <th>21144</th>
      <th>PINK POODLE HANGING DECORATION</th>
      <td>-12.000000</td>
      <td>-4.560000</td>
    </tr>
    <tr>
      <th>D</th>
      <th>Discount</th>
      <td>-15.506494</td>
      <td>-73.976883</td>
    </tr>
    <tr>
      <th>21645</th>
      <th>ASSORTED TUTTI FRUTTI ROUND BOX</th>
      <td>-24.000000</td>
      <td>-39.600000</td>
    </tr>
  </tbody>
</table>
<p>3916 rows × 2 columns</p>
</div>




```python
pip install --upgrade nbconvert 
```

    Requirement already satisfied: nbconvert in c:\users\admin\anaconda3\lib\site-packages (7.11.0)
    Requirement already satisfied: beautifulsoup4 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (4.12.2)
    Requirement already satisfied: bleach!=5.0.0 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (4.1.0)
    Requirement already satisfied: defusedxml in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (0.7.1)
    Requirement already satisfied: jinja2>=3.0 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (3.1.2)
    Requirement already satisfied: jupyter-core>=4.7 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (5.3.0)
    Requirement already satisfied: jupyterlab-pygments in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (0.1.2)
    Requirement already satisfied: markupsafe>=2.0 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (2.1.1)
    Requirement already satisfied: mistune<4,>=2.0.3 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (3.0.2)
    Requirement already satisfied: nbclient>=0.5.0 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (0.5.13)
    Requirement already satisfied: nbformat>=5.7 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (5.7.0)
    Requirement already satisfied: packaging in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (23.0)
    Requirement already satisfied: pandocfilters>=1.4.1 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (1.5.0)
    Requirement already satisfied: pygments>=2.4.1 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (2.15.1)
    Requirement already satisfied: tinycss2 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (1.2.1)
    Requirement already satisfied: traitlets>=5.1 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (5.7.1)
    Requirement already satisfied: six>=1.9.0 in c:\users\admin\anaconda3\lib\site-packages (from bleach!=5.0.0->nbconvert) (1.16.0)
    Requirement already satisfied: webencodings in c:\users\admin\anaconda3\lib\site-packages (from bleach!=5.0.0->nbconvert) (0.5.1)
    Requirement already satisfied: platformdirs>=2.5 in c:\users\admin\anaconda3\lib\site-packages (from jupyter-core>=4.7->nbconvert) (2.5.2)
    Requirement already satisfied: pywin32>=300 in c:\users\admin\anaconda3\lib\site-packages (from jupyter-core>=4.7->nbconvert) (305.1)
    Requirement already satisfied: jupyter-client>=6.1.5 in c:\users\admin\anaconda3\lib\site-packages (from nbclient>=0.5.0->nbconvert) (7.4.9)
    Requirement already satisfied: nest-asyncio in c:\users\admin\anaconda3\lib\site-packages (from nbclient>=0.5.0->nbconvert) (1.5.6)
    Requirement already satisfied: fastjsonschema in c:\users\admin\anaconda3\lib\site-packages (from nbformat>=5.7->nbconvert) (2.16.2)
    Requirement already satisfied: jsonschema>=2.6 in c:\users\admin\anaconda3\lib\site-packages (from nbformat>=5.7->nbconvert) (4.17.3)
    Requirement already satisfied: soupsieve>1.2 in c:\users\admin\anaconda3\lib\site-packages (from beautifulsoup4->nbconvert) (2.4)
    Requirement already satisfied: attrs>=17.4.0 in c:\users\admin\anaconda3\lib\site-packages (from jsonschema>=2.6->nbformat>=5.7->nbconvert) (22.1.0)
    Requirement already satisfied: pyrsistent!=0.17.0,!=0.17.1,!=0.17.2,>=0.14.0 in c:\users\admin\anaconda3\lib\site-packages (from jsonschema>=2.6->nbformat>=5.7->nbconvert) (0.18.0)
    Requirement already satisfied: entrypoints in c:\users\admin\anaconda3\lib\site-packages (from jupyter-client>=6.1.5->nbclient>=0.5.0->nbconvert) (0.4)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\admin\anaconda3\lib\site-packages (from jupyter-client>=6.1.5->nbclient>=0.5.0->nbconvert) (2.8.2)
    Requirement already satisfied: pyzmq>=23.0 in c:\users\admin\anaconda3\lib\site-packages (from jupyter-client>=6.1.5->nbclient>=0.5.0->nbconvert) (23.2.0)
    Requirement already satisfied: tornado>=6.2 in c:\users\admin\anaconda3\lib\site-packages (from jupyter-client>=6.1.5->nbclient>=0.5.0->nbconvert) (6.3.2)
    Note: you may need to restart the kernel to use updated packages.
    


```python
pip install nbconvert
```

    Requirement already satisfied: nbconvert in c:\users\admin\anaconda3\lib\site-packages (7.11.0)Note: you may need to restart the kernel to use updated packages.
    
    Requirement already satisfied: beautifulsoup4 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (4.12.2)
    Requirement already satisfied: bleach!=5.0.0 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (4.1.0)
    Requirement already satisfied: defusedxml in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (0.7.1)
    Requirement already satisfied: jinja2>=3.0 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (3.1.2)
    Requirement already satisfied: jupyter-core>=4.7 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (5.3.0)
    Requirement already satisfied: jupyterlab-pygments in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (0.1.2)
    Requirement already satisfied: markupsafe>=2.0 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (2.1.1)
    Requirement already satisfied: mistune<4,>=2.0.3 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (3.0.2)
    Requirement already satisfied: nbclient>=0.5.0 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (0.5.13)
    Requirement already satisfied: nbformat>=5.7 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (5.7.0)
    Requirement already satisfied: packaging in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (23.0)
    Requirement already satisfied: pandocfilters>=1.4.1 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (1.5.0)
    Requirement already satisfied: pygments>=2.4.1 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (2.15.1)
    Requirement already satisfied: tinycss2 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (1.2.1)
    Requirement already satisfied: traitlets>=5.1 in c:\users\admin\anaconda3\lib\site-packages (from nbconvert) (5.7.1)
    Requirement already satisfied: six>=1.9.0 in c:\users\admin\anaconda3\lib\site-packages (from bleach!=5.0.0->nbconvert) (1.16.0)
    Requirement already satisfied: webencodings in c:\users\admin\anaconda3\lib\site-packages (from bleach!=5.0.0->nbconvert) (0.5.1)
    Requirement already satisfied: platformdirs>=2.5 in c:\users\admin\anaconda3\lib\site-packages (from jupyter-core>=4.7->nbconvert) (2.5.2)
    Requirement already satisfied: pywin32>=300 in c:\users\admin\anaconda3\lib\site-packages (from jupyter-core>=4.7->nbconvert) (305.1)
    Requirement already satisfied: jupyter-client>=6.1.5 in c:\users\admin\anaconda3\lib\site-packages (from nbclient>=0.5.0->nbconvert) (7.4.9)
    Requirement already satisfied: nest-asyncio in c:\users\admin\anaconda3\lib\site-packages (from nbclient>=0.5.0->nbconvert) (1.5.6)
    Requirement already satisfied: fastjsonschema in c:\users\admin\anaconda3\lib\site-packages (from nbformat>=5.7->nbconvert) (2.16.2)
    Requirement already satisfied: jsonschema>=2.6 in c:\users\admin\anaconda3\lib\site-packages (from nbformat>=5.7->nbconvert) (4.17.3)
    Requirement already satisfied: soupsieve>1.2 in c:\users\admin\anaconda3\lib\site-packages (from beautifulsoup4->nbconvert) (2.4)
    Requirement already satisfied: attrs>=17.4.0 in c:\users\admin\anaconda3\lib\site-packages (from jsonschema>=2.6->nbformat>=5.7->nbconvert) (22.1.0)
    Requirement already satisfied: pyrsistent!=0.17.0,!=0.17.1,!=0.17.2,>=0.14.0 in c:\users\admin\anaconda3\lib\site-packages (from jsonschema>=2.6->nbformat>=5.7->nbconvert) (0.18.0)
    Requirement already satisfied: entrypoints in c:\users\admin\anaconda3\lib\site-packages (from jupyter-client>=6.1.5->nbclient>=0.5.0->nbconvert) (0.4)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\admin\anaconda3\lib\site-packages (from jupyter-client>=6.1.5->nbclient>=0.5.0->nbconvert) (2.8.2)
    Requirement already satisfied: pyzmq>=23.0 in c:\users\admin\anaconda3\lib\site-packages (from jupyter-client>=6.1.5->nbclient>=0.5.0->nbconvert) (23.2.0)
    Requirement already satisfied: tornado>=6.2 in c:\users\admin\anaconda3\lib\site-packages (from jupyter-client>=6.1.5->nbclient>=0.5.0->nbconvert) (6.3.2)
    


```python
pip install pyppeteer
```

    Requirement already satisfied: pyppeteer in c:\users\admin\anaconda3\lib\site-packages (1.0.2)
    Requirement already satisfied: appdirs<2.0.0,>=1.4.3 in c:\users\admin\anaconda3\lib\site-packages (from pyppeteer) (1.4.4)
    Requirement already satisfied: certifi>=2021 in c:\users\admin\anaconda3\lib\site-packages (from pyppeteer) (2023.7.22)
    Requirement already satisfied: importlib-metadata>=1.4 in c:\users\admin\anaconda3\lib\site-packages (from pyppeteer) (6.0.0)
    Requirement already satisfied: pyee<9.0.0,>=8.1.0 in c:\users\admin\anaconda3\lib\site-packages (from pyppeteer) (8.2.2)
    Requirement already satisfied: tqdm<5.0.0,>=4.42.1 in c:\users\admin\anaconda3\lib\site-packages (from pyppeteer) (4.65.0)
    Requirement already satisfied: urllib3<2.0.0,>=1.25.8 in c:\users\admin\anaconda3\lib\site-packages (from pyppeteer) (1.26.16)
    Requirement already satisfied: websockets<11.0,>=10.0 in c:\users\admin\anaconda3\lib\site-packages (from pyppeteer) (10.4)
    Requirement already satisfied: zipp>=0.5 in c:\users\admin\anaconda3\lib\site-packages (from importlib-metadata>=1.4->pyppeteer) (3.11.0)
    Requirement already satisfied: colorama in c:\users\admin\anaconda3\lib\site-packages (from tqdm<5.0.0,>=4.42.1->pyppeteer) (0.4.6)
    Note: you may need to restart the kernel to use updated packages.
    


```python

```
